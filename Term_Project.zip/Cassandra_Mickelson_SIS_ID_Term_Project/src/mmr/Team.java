package mmr;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import javax.swing.JTable;

public class Team implements Comparable<Team>{
	private ArrayList<Player> team = new ArrayList<>();
	private Boolean won;
	private Color color = Color.WHITE;
	private HashMap<Player, Float> contributions = new HashMap<>();
	private static final String ERROR = "Final match results have not been initialized.";
	
	/**Constructs a new Team.*/
	public Team(Player[] players){
		constructorHelper(players);
	}
	
	/**Constructs a new Team.*/
	public Team(Player[] players, Color color){
		this.color = color;
		constructorHelper(players);
	}
	
	/**Constructs a new Team.*/
	public Team(ArrayList<Player> players){
		constructorHelper(players.toArray(new Player[players.size()]));
	}
	
	/**Constructs a new Team.*/
	public Team(ArrayList<Player> players, Color color){
		this.color = color;
		constructorHelper(players.toArray(new Player[players.size()]));
	}
	
	/**Performs the bulk of initial construction. This method was created to avoid redundant code in the overloaded constructors.*/
	private void constructorHelper(Player[] players){
		for(Player player : players){
			team.add(player.clone());
		}
		team.trimToSize();
		Collections.sort(team);
	}
	
	/**Note: this class has a natural ordering that is inconsistent with equals.*/
	public int compareTo(Team two){
		//First segment would be removed for >2 team version.
		if(won != null){
			if(won == true){
				return -1;
			} else{
				return 1;
			}
		}
		short oKills = getKills();
		short tKills = two.getKills();
		float oKDA = getKDA();
		float tKDA = two.getKDA();
		if(oKills > tKills){
			return -1;
		} else if(oKills < tKills){
			return 1;
		} else if(oKDA > tKDA){
			return -1;
		} else if(oKDA < tKDA){
			return 1;
		} else{
			System.out.println("Tie game. Expect errors.");
			return 0;
		}
	}
	
	/**Returns if both Objects are the same Team.*/
	public boolean equals(Object obj){
		if(this == obj){
			return true;
		}
		return equals(((Team)obj).getTeam());
	}
	
	/**Returns if this Team contains the same players as a given Player array.*/
	public boolean equals(Player[] team){
		if(size() == team.length){
    		Arrays.sort(team);
    		boolean result = true;
    		Player other;
	    	for(short i = 0; i < size(); i++){
	    		other = team[i];
	    		if(getPlayer(i).equals(other)){
	    			return false;
	    		} else if(!(getPlayer(i).getKills() == other.getKills() && getPlayer(i).getDeaths() == other.getDeaths() && getPlayer(i).getAssists() == other.getAssists())){
	    			return false;
	    		}
	    	}
	    	return result;
    	} else{
    	    return false;
		}
	}
    
	/**Returns a Player's contribution.*/
    public Float getContribution(Player player){
    	Float result = null;
    	try{
        	result = contributions.get(player);
    	} catch(NullPointerException npe){
    		System.out.println(ERROR);
    	}
    	return result;
    }
    
	/**Returns the contribution of every player on the team.*/
    public HashMap<Player, Float> getContributions(){
    	return contributions;
    }
    
    /**Returns this Team's Assists.*/
    public short getAssists(){
    	short result = 0;
    	for(short i = 0; i < size(); i++){
    		result += team.get(i).getAssists();
    	}
    	return result;
    }
    
    /**Returns this Team's Deaths.*/
    public short getDeaths(){
    	short result = 0;
    	for(short i = 0; i < size(); i++){
    		result += team.get(i).getDeaths();
    	}
    	return result;
    }
	
    /**Returns this Team's kda ratio.*/
    public float getKDA(){
    	short denom = getDeaths();
    	if(denom < 1){
    		denom = 1;
    	}
    	return Player.tdp((0.5f * getAssists() + getKills()) / denom);
    }
	
    /**Returns this Team's kdr.*/
    public float getKDR(){
    	float denom = getDeaths();
    	if(denom < 1){
    		denom = 0.9f;
    	}
    	return Player.tdp(getKills() / denom);
    }
    
    /**Returns this Team's Kills.*/
    public short getKills(){
    	short result = 0;
    	for(short i = 0; i < size(); i++){
    		result += team.get(i).getKills();
    	}
    	return result;
    }
    
    /**Returns which Player is in the specified position on this Team.*/
    public Player getPlayer(int index){
    	return team.get(index).clone();
    }
    
    /**Returns an array of the Players on this Team.*/
    public Player[] getTeam(){
    	Player[] players = new Player[size()];
    	for(short i = 0; i < size(); i++){
    		players[i] = team.get(i).clone();
    	}
    	return players;
    }
    
    /**Assigns if this team won.*/
    //Currently only sets Player contributions correctly for winning Team.
    public void setWinner(boolean medal){
    	won = medal;
    	float[] temp = new float[size()]; //Array of Player KDAs
    	for(short i = 0; i < size(); i++){
    		temp[i] = team.get(i).getKDA();
    	}
    	float total = sum(temp);
    	for(short i = 0; i < size(); i++){
    		//MMRSystem.output(team.get(i) + " :: " + temp[i] / total); //Bug testing*^*^*
    		contributions.put(team.get(i), temp[i] / total);
    	}
    	if(!won){
    		for(short i = 0; i < size(); i++){
    			float denom = contributions.get(team.get(i));
    			if(denom < 0.005f){
    				denom = 0.005f;
    			}
        		temp[i] = 1 / denom;
        	}
        	total = sum(temp);
        	for(short i = 0; i < size(); i++){
        		//MMRSystem.output(team.get(i) + " :: " + temp[i] / total * -1); //Bug testing*^*^*
        		contributions.put(team.get(i), temp[i] / total * -1);
        	}
    	}
    }
    
	/**Returns the number of Players on this Team.*/
    public int size(){
    	return team.size();
    }

	/**Calculates the sum of an array of floats.*/
	protected static float sum(float[] nums){
		float total = 0;
		for(float num : nums){
			total += num;
		}
		return total;
	}

	/**Returns a JTable representation of this Team.*/
    public JTable toJTable(){
    	String[] headers = {"Player", "Kills", "Deaths", "Assists", "KDA"};
    	Object[][] players = new Object[size() + 1][Player.LENGTH];
    	players[0] = headers;
    	for(short i = 0; i < size(); i++){
    		players[i + 1] = team.get(i).toObjectArray();
    	}
    	JTable result = new JTable(players, headers);
    	result.setForeground(Color.WHITE);
    	result.setBackground(color);
    	return result;
    }
	
    /**Returns a String representation of this Team.*/
	public String toString(){
		StringBuilder result = new StringBuilder("<Team>\n");
		for(Player player : team){
			result.append(player + "\n");
		}
		result.append("</Team>");
		return result.toString();
	}
	
	/**Returns if this Team won.*/
    public boolean won(){
    	if(won != null){
    		return won;
    	} else{
    		throw new NullPointerException(ERROR);
    	}
    }
}
