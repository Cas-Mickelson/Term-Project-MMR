package mmr;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

public class MMRSystem implements ActionListener{
	private static JTabbedPane tabPane = new JTabbedPane();
	private static Team[] competitors;
	//Blue, red, yellow, purple, orange, green.
	private static final Color[] RAINBOW = {new Color(0x0000FF), new Color(0xFF0000), new Color(0xFFFF00), new Color(0xA020F0), new Color(0xFFA500), new Color(0x007F00)};
	//private static final short TEAM_COUNT = 2;
	private static final short TEAM_SIZE = 5;
	private static final short WAGER = 120;
	protected static Leaderboard leaderboard = new Leaderboard();
	
	public static void main(String[] args){
		MMRSystem self = new MMRSystem();
		JFrame frame = makeFrame("MMR", 0.800, 0.800);
        tabPane = new JTabbedPane();
        JScrollPane matchTab = makeMatchTab();
        //matchTab.setVisible(true);
        JMenuBar bar = new JMenuBar();
        JMenu fileM = new JMenu("File");
        
        tabPane.add("Results", matchTab);
        tabPane.add("Leaderboard", new JScrollPane(leaderboard.toJTable()));
        frame.add(tabPane);
        
        fileM.add(makeMenuItem("Import", self));
        fileM.add(makeMenuItem("Reset", self));
        fileM.add(makeMenuItem("Exit", self));
        bar.add(fileM);
        frame.setJMenuBar(bar);
        frame.setVisible(true);
	}
	
	/**Handles all ActionEvents caused by MenuItems.*/
    public void actionPerformed(ActionEvent evt){
    	if(evt.getActionCommand().equals("Import")){
    		write(competitors);
    		paintLeaderboard();
    	} else if(evt.getActionCommand().equals("Reset")){
    	    Leaderboard.reset();
    	    paintLeaderboard();
    	} else if(evt.getActionCommand().equals("Exit")){
    	    System.exit(0);
    	}
    }
    
    /**Creates a JFrame with size set to a percent value of the screen size (represented as a decimal).*/
    public static JFrame makeFrame(String title, double pctWth, double pctHgt){
    	Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    	JFrame frame = new JFrame(title);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize((int)(d.width * pctWth), (int)(d.height * pctHgt));
    	return frame;
    }
    
    /**Creates the JScrollPane that will fill the Match tab.*/
    private static JScrollPane makeMatchTab(){
    	competitors = readResults();
    	JPanel tab = new JPanel();
    	tab.setBackground(Color.LIGHT_GRAY);
    	tab.setLayout(new BoxLayout(tab, BoxLayout.Y_AXIS));
    	for(short i = 0; i < competitors.length; i++){
    		tab.add(competitors[i].toJTable());
    	}
    	JScrollPane result = new JScrollPane(tab);
    	return result;
    }
    
    /**Creates a JMenuItem with al as its ActionListener and key as its text and ActionCommand.*/
    public static JMenuItem makeMenuItem(String key, ActionListener al){
    	JMenuItem item = new JMenuItem(key);
    	item.addActionListener(al);
    	item.setActionCommand(key);
    	return item;
    }
    
    /**Parses a string to construct a Player.*/
	public static Player nextPlayer(String line){
		String[] data = line.split(",");
		return new Player(Integer.parseInt(data[0]), data[1], Short.parseShort(data[2]), Short.parseShort(data[3]), Short.parseShort(data[4]));
	}
	
	/**Saves keystrokes to call System.out.println().*/
    public static void output(String msg){
    	System.out.println(msg);
    }
    
    /**Iterates through an array from back to front, subtracting one from each until the sum of the array reaches the target.*/
    private static short[] punishScabs(short[] preliminary, short target){
    	short p = (short)(preliminary.length - 1); //pointer
    	short sum = sum(preliminary);
    	while(Math.abs(sum) != target){
    		sum -= 1;
    		preliminary[p] -= 1;
    		p--;
    		if(p < 0){
    			p = (short)(preliminary.length - 1);
    		}
    	}
    	return preliminary;
    }
    
    /***/
    public static Team[] readResults(){
    	//Construct array of teams.
    	ArrayList<Team> result = new ArrayList<>();
    	ArrayList<Player> players = new ArrayList<>();
    	try(BufferedReader br = new BufferedReader(new FileReader("src/mmr/results.csv"))){
    		short counter = 0;
    	    String line;
    	    while((line = br.readLine()) != null){
    	    	if(line.length() <= 1){
    	    		result.add(new Team(players, RAINBOW[counter]));
    	    		players.clear();
    	    		counter++;
    	    	} else{
    	    		players.add(nextPlayer(line));
    	    	}
    	    }
    	    result.add(new Team(players, RAINBOW[counter]));
    	} catch (FileNotFoundException e){
    		output("It can't find the file.");
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
    	
    	//Set winner and losers.
    	Collections.sort(result);
    	boolean counter = true;
    	for(Team t : result){
			t.setWinner(counter);
    		if(counter){
    			counter = false;
    		}
    	}
    	
    	return result.toArray(new Team[result.size()]);
    }
    
    /**Repaints the leaderboard tab.*/
    private static void paintLeaderboard(){
    	int activeTab = tabPane.getSelectedIndex();
	    tabPane.remove(1);
	    tabPane.add("Leaderboard", new JScrollPane(leaderboard.toJTable()));
	    tabPane.revalidate();
	    tabPane.repaint();
	    tabPane.setSelectedIndex(activeTab);
    }
    
    /**Iterates over a HashMap to print its contents.*/
    public static void printMap(HashMap<Player, Short> map){
        for(HashMap.Entry<Player, Short> entry : map.entrySet()){
            output(entry.getKey() + " " + entry.getValue());
        }
    }
    
    /**Iterates through an array from front to back, adding one to each until the sum of the array reaches the target.*/
    private static short[] rewardAchievement(short[] preliminary, short target){
    	short p = 0;
    	short sum = sum(preliminary);
    	while(Math.abs(sum) != target){
    		sum += 1;
    		preliminary[p] += 1;
    		p++;
    		if(p >= preliminary.length){
    			p = 0;
    		}
    	}
    	return preliminary;
    }

	/**Calculates the sum of an array of shorts.*/
	protected static short sum(short[] nums){
		short total = 0;
		for(short num : nums){
			total += num;
		}
		return total;
	}
    
    public static void write(Team[] teams){
    	//Parallel array of arrays holding the resulting mmr change before writing for each team [t][], and each player [][p].
    	short[][] delta = new short[teams.length][];
    	for(short t = 0; t < teams.length; t++){
    		delta[t] = new short[teams[t].size()];
    	}
    	//Performs the actual math
    	short TEAM_WAGER = TEAM_SIZE * WAGER;
    	for(short t = 0; t < delta.length; t++){
    		//Initial baseline MMR change, which may be fine as-is.
    		short sum = 0;
    		for(short p = 0; p < delta[t].length; p++){
    			short indivChange = (short)Math.round(TEAM_WAGER * teams[t].getContribution(teams[t].getPlayer(p)));
    			delta[t][p] = indivChange;
    			sum += indivChange;
    		}
    		
    		//If change is too small...
    		if(Math.abs(sum) < TEAM_WAGER){
    			//and won, add MMR to highest players in order.
    			if(teams[t].won()){
    				//output("Small, won.");
    				delta[t] = rewardAchievement(delta[t], TEAM_WAGER);
    			//and lost, remove MMR from lowest players in order.
    			} else{
    				//output("Small, lost.");
    				delta[t] = punishScabs(delta[t], TEAM_WAGER);
    			}
    		//If change is too large...
    		} else if(Math.abs(sum) > TEAM_WAGER){
    			//and won, remove MMR from lowest players in order.
    			if(teams[t].won()){
    				//output("Large, won.");
    				delta[t] = punishScabs(delta[t], TEAM_WAGER);
    			//and lost, add MMR to highest players in order.
    			} else{
    				//output("Large, lost.");
    				delta[t] = rewardAchievement(delta[t], TEAM_WAGER);
    			}
    		}
    	}
    	
    	//Constructs data type to pass to Leaderboard.
    	HashMap<Player, Short> result = new HashMap<>();
    	for(short t = 0; t < delta.length; t++){
    		for(short p = 0; p < delta[t].length; p++){
    			result.put(teams[t].getPlayer(p), delta[t][p]);
    		}
    	}
    	Leaderboard.write(result);
    }
}
