package mmr;

class Player implements Comparable<Player>{
	protected static final int LENGTH = 5;
	private int id;
	private short assists;
	private short deaths;
	private short kills;
	private String username;
	
	/**Constructs a new Player.*/
    public Player(int id, String name, short kills, short deaths, short assists){
    	setAssists(assists);
    	setDeaths(deaths);
    	setID(id);
    	setKills(kills);
    	setUsername(name);
    }
    
    /**Returns a copy of this Player instance.*/
    public Player clone(){
    	return new Player(id, new String(username), kills, deaths, assists);
    }
	
    /**Returns <0 if KDA is greater than other's KDA, >0 if KDA is less than other's KDA.
     * If KDA's are equal, compares kill counts, then death counts; if both are equal sorts by ID.
     * Note: this class has a natural ordering that is inconsistent with equals.*/
	public int compareTo(Player two){
		float mine = getKDA();
		float theirs = two.getKDA();
		if(mine > theirs){
			return -1;
		} else if(mine < theirs){
			return 1;
		} else if(kills > two.getKills()){
			return -1;
		} else if(kills < two.getKills()){
			return 1;
		} else if(deaths < two.getDeaths()){
			return -1;
		} else if(deaths > two.getDeaths()){
			return 1;
		} else if(id < two.getID()){
			return -1;
		} else if(id > two.getID()){
			return 1;
		} else{
			return username.compareTo(two.getUsername());
		}
	}
	
	/**Returns if both Objects are the same Player.*/
	public boolean equals(Object obj){
		if(this == obj || (obj instanceof Player && id == ((Player)obj).getID())){
    		return true;
    	} else{
    	    return false;
		}
	}
	
    /**Returns this Player's assist count.*/
    public short getAssists(){
    	return assists;
    }
	
    /**Returns this Player's death count.*/
    public short getDeaths(){
    	return deaths;
    }
	
    /**Returns this Player's ID.*/
    public int getID(){
    	return id;
    }
	
    /**Returns this Player's kda ratio.*/
    public float getKDA(){
    	return tdp((0.5f * assists + kills) / (deaths + 1));
    }
	
    /**Returns this Player's kdr.*/
    public float getKDR(){
    	float denom = deaths;
    	if(deaths < 1){
    		denom = 0.9f;
    	}
    	return tdp(kills / denom);
    }
	
    /**Returns this Player's kill count.*/
    public short getKills(){
    	return kills;
    }
	
    /**Returns this Player's username.*/
    public String getUsername(){
    	return username;
    }
    
    /**Returns a hash code for this Player.*/
    public int hashCode(){
        return 31 * getClass().hashCode() + id;
    }
    
    /**Redefines this Player's assist count.*/
    public void setAssists(short quant){
    	assists = (short)Math.abs(quant);
    }
    
    /**Redefines this Player's death count.*/
    public void setDeaths(short quant){
    	deaths = (short)Math.abs(quant);
    }
    
    /**Redefines this Player's ID.*/
    public void setID(int id){
    	this.id = Math.abs(id);
    }
    
    /**Redefines this Player's kill count.*/
    public void setKills(short quant){
    	kills = (short)Math.abs(quant);
    }
    
    /**Redefines this Player's username.*/
    public void setUsername(String name){
    	username = name;
    }
    
    /**Rounds a float to two decimal places.*/
    protected static float tdp(float num){
		return Math.round(num * 100.0) / 100.0f;
	}
	
    /**Returns an array of Objects representing this Player.*/
	protected Object[] toObjectArray(){
		//Update LENGTH when changing the following array!
		Object[] result = {new String(username), kills, deaths, assists, getKDA()};
		return result;
	}
	
    /**Returns a String representation of this Player.*/
	public String toString(){
		return "<" + username + ", " + kills + ", " + deaths + ", " + assists + "/>";
	}
}
