package mmr;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import javax.swing.JTable;

public class Leaderboard{
	private static HashMap<Integer, Integer> indices = new HashMap<>();
	private static ArrayList<Record> leaderboard = new ArrayList<>();
	
	/**Constructs a new Leaderboard.*/
	public Leaderboard(){
		read();
		sort();
	}
	
	/**Adds a new Record to the Leaderboard.
	 * Remember to call .sort() after calling this method.*/
	private static void append(Record record){
		leaderboard.add(record);
	}
	
	/**Returns the number of entries on the Leaderboard.*/
	public static int length(){
		return leaderboard.size();
	}
	
	/**Parses a string to construct a Record.*/
	private static Record nextRecord(String line){
		String[] data = line.split(",");
		return new Record(Integer.parseInt(data[0].replace(",", "")), data[1], Integer.parseInt(data[2].replace(",", "")));
	}
    
    /**Iterates over a HashMap to print its contents.*/
    public static void printMap(HashMap<Player, Float> map){
        for(HashMap.Entry<Player, Float> entry : map.entrySet()){
            MMRSystem.output(entry.getKey() + " " + entry.getValue());
        }
    }
	
	/**Reads the leaderboard.csv database to utilize and modify it.*/
	private static void read(){
    	try(BufferedReader br = new BufferedReader(new FileReader("src/mmr/leaderboard.csv"))){
    	    String line;
    	    while((line = br.readLine()) != null){
    	    	if(line.length() != 0){
        	    	leaderboard.add(nextRecord(line));
    	    	}
    	    }
    	} catch (FileNotFoundException e){
    		MMRSystem.output("It can't find the file.");
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/**Resets the leaderboard.*/
	protected static void reset(){
		for(Record current : leaderboard){ //All players needing MMR change
			current.setMMR(0);
		}
		writeHelper();
	}
	
	/**Sorts this Leaderboard.*/
	private static void sort(){
		Collections.sort(leaderboard);
		for(int i = 0; i < length(); i++){
			indices.put(leaderboard.get(i).getID(), i);
		}
	}
	
	/**Returns a JTable representation of this Leaderboard.*/
    public JTable toJTable(){
    	String[] headers = {"Rank", "Username", "MMR"};
    	Object[][] records = new Object[length()][Record.LENGTH];
    	for(short i = 0; i < length(); i++){
    		records[i] = leaderboard.get(i).toObjectArray(i + 1);
    	}
    	JTable result = new JTable(records, headers);
    	result.setBackground(Color.WHITE);
    	return result;
    }
	
	/**Writes the Leaderboard in memory to leaderboard.csv*/
	public static void write(HashMap<Player, Short> contributions){ //Hashmap of Player ID's and MMR changes
		for(Player current : contributions.keySet()){ //All players needing MMR change
			int id = current.getID();
			if(indices.containsKey(id)){ //If not a new player
				leaderboard.get(indices.get(id)).mutateMMR(contributions.get(current)); //Changes target player's mmr according to the given HashMap
			} else{ //Add new player to leaderboard
				append(new Record(id, current.getUsername(), contributions.get(current)));
			}
		}
		writeHelper();
	}
	
	/**Actually writes the Leaderboard in memory to leaderboard.csv*/
	private static void writeHelper(){
		sort();
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/mmr/leaderboard.csv"))){
			StringBuilder result = new StringBuilder();
			for(Record record : leaderboard){
				result.append(record + "\n");
			}
		    writer.write(result.toString().trim());
		} catch (IOException e){
		    e.printStackTrace();
		}
	}
}

class Record implements Comparable<Record>{
	protected static final int LENGTH = 3;
	private int id;
	private int mmr = 0;
	private String username;
	
	/**Constructs a new Record.*/
	public Record(int id, String name, int mmr){
		setID(id);
		setMMR(mmr);
		setUsername(name);
	}
	
	/**Returns <0 if MMR is greater than other's MMR, >0 if MMR is less than other's MMR.
     * If MMR's are equal, sorts by ID.
     * Note: this class has a natural ordering that is inconsistent with equals.*/
	public int compareTo(Record two){
		if(mmr > two.getMMR()){
			return -1;
		} else if(mmr < two.getMMR()){
			return 1;
		} else if(id < two.getID()){
			return -1;
		} else if(id > two.getID()){
			return 1;
		} else{
			return username.compareTo(two.getUsername());
		}
	}
	
	/**Returns if both Objects are the same Record.*/
	public boolean equals(Object obj){
		if(this == obj || (obj instanceof Record && id == ((Record)obj).getID())){
    		return true;
    	} else{
    	    return false;
		}
	}
	
    /**Returns this Record's ID.*/
    public int getID(){
    	return id;
    }
	
    /**Returns this Record's MMR.*/
    public int getMMR(){
    	return mmr;
    }
	
    /**Returns this Record's username.*/
    public String getUsername(){
    	return username;
    }
    
    /**Returns a hash code for this Record.*/
    public int hashCode(){
        return 31 * getClass().hashCode() + id;
    }
    
    /**Changes this Record's MMR by the given value.*/
    protected void mutateMMR(short change){
    	this.mmr += change;
    }
    
    /**Redefines this Record's ID.*/
    private void setID(int id){
    	this.id = Math.abs(id);
    }
    
    /**Redefines this Record's MMR.*/
    protected void setMMR(int mmr){
    	this.mmr = mmr;
    }
    
    /**Redefines this Record's username.*/
    protected void setUsername(String name){
    	username = name;
    }
    
    /**Returns an array of Objects representing this Record.*/
	protected Object[] toObjectArray(int rank){
		//Update LENGTH when changing the following array!
		Object[] result = {rank, new String(username), mmr};
		return result;
	}
    
    /**Returns a String representation of this Record.*/
	public String toString(){
		return id + "," + username + "," + mmr;
	}
}
